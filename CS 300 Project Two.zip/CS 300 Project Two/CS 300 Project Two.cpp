// CS 300 Project Two.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>

using namespace std;

//Menu to display options the user can do
void menuOptions() {
cout << "Menu Options" << endl;
cout << "1. Load Data structure" << endl;
cout << "2. Print Course List" << endl;
cout << "3. Print Course" << endl;
cout << "4. Exit" << endl;
}

//structure used to hold courses name, id, and prerequisites information
struct Course {
    string courseId;
    string courseName;

    vector<string> prerequisite;
};


//Nodes in the binary tree that hold the course information
//Has left and right children for the nodes
struct Node {

    Course course;
    Node* leftNode;
    Node* rightNode;

    Node() {
        leftNode = nullptr;
        rightNode = nullptr;
    }

    Node(Course aCourse) : Node() {
        this->course = aCourse;
    }

};

class BinarySearchTree {

public:
    Node* root;
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void Insert(BinarySearchTree* tree, Node* node);
    void Search(string courseId);
    void PrintCourse(Node* node);
};

BinarySearchTree::BinarySearchTree() {

    root = nullptr;

}

BinarySearchTree::~BinarySearchTree()
{
}

//Searches course by courseID in file
void BinarySearchTree::Search(string courseId) {
    Node* currNode = root;

    while (currNode != nullptr) {
        if (currNode->course.courseId == courseId) {
            cout << currNode->course.courseId << ", ";
            cout << currNode->course.courseName << endl;
            cout << "Prerequisites: ";

            for (string prerequisite : currNode->course.prerequisite) {
                if (prerequisite == currNode->course.prerequisite.back()) {

                    cout << prerequisite << endl;
                }
                else {
                    cout << prerequisite << ", ";
                }
            }

            return;
        }

        else if (courseId < currNode->course.courseId) {

            if (currNode->leftNode != nullptr) {
                currNode = currNode->leftNode;
            }
        }
        else {
            currNode = currNode->rightNode;
        }
    }

    cout << "Course " << courseId << "Error Course Not Found." << endl;

    return;
}

 //Inserts course into course List
void BinarySearchTree::Insert(BinarySearchTree* tree, Node* node) {
    if (tree->root == nullptr) {
        tree->root = node;
    }
    else {
        Node* currNode = tree->root;
        while (currNode != nullptr) {

            if (node->course.courseId < currNode->course.courseId) {
                if (currNode->leftNode == nullptr) {
                    currNode->leftNode = node;
                    currNode = nullptr;
                }
                else {
                    currNode = currNode->leftNode;
                }
            }
            else {
                if (currNode->rightNode == nullptr) {
                    currNode->rightNode = node;
                    currNode = nullptr;
                }
                else {
                    currNode = currNode->rightNode;
                }
            }

        }
    }
}

//Prints the course ID and name
void BinarySearchTree::PrintCourse(Node* node) {

    if (node == nullptr) {
        return;
    }

    PrintCourse(node->leftNode);
    cout << node->course.courseId << ", " << node->course.courseName << endl;
    PrintCourse(node->rightNode);
};

//Loads the inputted file and reads from lines adding prerequisites if any
void LoadCourse(string fileName, BinarySearchTree* bst) {
    fstream file(fileName);
    if (file.is_open()) {
        cout << "File Opened." << endl;

        int num;
        string line;
        string word;

        //Loops till it reaches end of file
        while (getline(file, line)) {
            num = 0;
            Node* node = new Node();
            stringstream str(line);
            
            while (num < 2) {
                getline(str, word, ',');
                if (num == 0) {
                    node->course.courseId = word;
                }
                else {
                    node->course.courseName = word;
                }
                ++num;
            }

            // Takes the prerequisites and push them to the end
            while (getline(str, word, ',')) {
                node->course.prerequisite.push_back(word);
            }

            bst->Insert(bst, node);
        }
    }
    else {
        cout << "File Not Found" << endl;
        return;
    }
}


int main()
{
    BinarySearchTree* bst = new BinarySearchTree();

    string inputFile;
    string inputCourseId;

    int userMenuChoice = 0;

    cout << "Welcome to the Course Planner." << endl;
    cout << endl;

    while(userMenuChoice != 4) {
        menuOptions();
        cin >> userMenuChoice;

        //Allows of user options to call needed functions
        switch (userMenuChoice) {
       
        //Loads file
        case 1:
            cout << endl;
            cout << "What file would you like to load?";
            cout << endl;
            cin >> inputFile;

            LoadCourse(inputFile, bst);
            cout << endl;
            break;

        //Prints course in alphanumeric order
        case 2:
            cout << endl;
            cout << "Course ID:     Course Name:" << endl;
            bst->PrintCourse(bst->root);
            cout << endl;
            break;

         //Prints course information with prerequisites
        case 3:
            cout << endl;
            cout << "What course do you want to know about?" << endl;
            cin >> inputCourseId;
            cout << endl;

            std::transform(inputCourseId.begin(), inputCourseId.end(), inputCourseId.begin(), ::toupper);
            bst->Search(inputCourseId);

            cout << endl;
            break;
        
        //Ends program
        case 4:
            cout << "Thank you for using the Course Planner!" << endl;
            break;

        default:
            cout << userMenuChoice << " is not a valid option. Please input valid option." << endl;
            cout << endl;
            break;

        }
    }
    
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
